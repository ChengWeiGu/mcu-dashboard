import dash
import numpy as np
import time

from dash.dependencies import Input, Output, State
import dash_core_components as dcc
import dash_html_components as html
import dash_daq as daq
import dash_bootstrap_components as dbc
import dash_table

import plotly.graph_objs as go



TABLE_FORMAT = {
                'columns' : ['Item', 'Maximum Voltage(V)', 'Minimum Voltage(V)', 'Full Deviation(V)', 'Average Voltage(V)', 'RMS', 'STDEV(V)', 'CV(%)', 'OutPercentage%'],
                'data':[{'Item': 'Channel-%d'%(i+1), 
                        'Maximum Voltage(V)': 'N.A.', 
                        'Minimum Voltage(V)':'N.A.', 
                        'Full Deviation(V)':'N.A.', 
                        'Average Voltage(V)':'N.A.', 
                        'RMS':'N.A.',
                        'STDEV(V)':'N.A.',
                        'CV(%)':'N.A.',
                        'OutPercentage%':'N.A.'} for i in range(3)] #df.to_dict('records')              
                }
                

def build_DA_table():
    
    return html.Div(id = 'table-div',
                    className='row',
                     children = [
                        html.Div(children = dbc.Button('Export', id = 'export-2-btn', n_clicks = 0, disabled = True)),
                        dash_table.DataTable(
                                                id='data-2-table',
                                                columns=[{"name": n, "id": n} for n in TABLE_FORMAT['columns']],
                                                # editable=True,
                                                style_as_list_view=True,
                                                data=TABLE_FORMAT['data'],
                                                # export_format="csv",
                                                style_cell = {'font_family': 'Arial','font_size': '14px', 'text_align': 'center'},
                                                style_header={'backgroundColor': 'rgba(0,0,0,0)','fontWeight': 'bold'},
                                                style_data={'backgroundColor': 'rgba(0,0,0,0)','fontWeight': 'bold'},
                                            )
                    ])
                    
                    
                    
def build_statistic_line(line_num, max_id, max_val, min_id, min_val, ave_id, ave_val):
    return html.Div(
        id=line_num,
        children=[
            html.Div(id=max_id, children=max_val , className="four columns", style={"text-align":"center"}),
            html.Div(id=min_id, children=min_val , className="four columns", style={"text-align":"center"}),
            html.Div(id=ave_id, children=ave_val , className="four columns", style={"text-align":"center"}),
        ],
        className="row",
    )

def build_osci_statistic_list(channel):
    return html.Div(id = 'OSCIStatistic-Div',
                    children=[
                            build_statistic_line("first-row-statistic", "max-tag", "Maximum (V)", "min-tag", "Minimum (V)", "ave-tag", "Average (V)"),
                            build_statistic_line(f"second-row-statistic-{channel}", f"max-val-tag-{channel}", "--", f"min-val-tag-{channel}", "--", f"ave-val-tag-{channel}", "--"), 
                        ])              