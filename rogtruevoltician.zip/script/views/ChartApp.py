import dash
import numpy as np
import time

from dash.dependencies import Input, Output, State
import dash_core_components as dcc
import dash_html_components as html
import dash_daq as daq
import dash_bootstrap_components as dbc
import dash_table

import plotly.graph_objs as go


SOFTWARE_SPEED = 100.0


global SPEC_PARAMS

SPEC_PARAMS = {
                'osci':{
                        'channel-1':{
                                    'v_ratio':3, # 3 or 5 or 12
                                    'ucl':1.5,
                                    'lcl':0.8,
                                    'trv':2.8,
                                    'tfv':1.4,
                                    'fv':3.3,
                                    'tucl_chk':[],
                                    'tlcl_chk':[],
                                    'fucl_chk':[],
                                    },
                        'channel-2':{
                                    'v_ratio':3, # 3 or 5 or 12
                                    'ucl':1.5,
                                    'lcl':0.8,
                                    'trv':2.8,
                                    'tfv':1.4,
                                    'fv':3.3,
                                    'tucl_chk':[],
                                    'tlcl_chk':[],
                                    'fucl_chk':[],
                                    },
                        'channel-3':{
                                    'v_ratio':3, # 3 or 5 or 12
                                    'ucl':1.5,
                                    'lcl':0.8,
                                    'trv':2.8,
                                    'tfv':1.4,
                                    'fv':3.3,
                                    'tucl_chk':[],
                                    'tlcl_chk':[],
                                    'fucl_chk':[],
                                    }
                        },
                'DA':{
                        'ucl':3.0,
                        'lcl':0.0,
                        'v_ratio':3
                    }
                
                }
                
                


global FIGURE_FORMAT
FIGURE_FORMAT ={
                'title': 'Voltage Data',
                'channel':[1,2,3],
                'linecolor':['rgb(0,0,255)','rgb(0,204,204)','rgb(128,0,128)'],
                'DA_linecolor':['rgb(255,0,0)','rgb(0,255,245)','rgb(255,255,0)'],
                'osci_linecolor':['rgb(255,0,0)','rgb(0,255,245)','rgb(255,255,0)'],
                "DA_layout":{
                            "title": "Voltage Data",
                            "font": dict(color="darkgray"),
                            "paper_bgcolor": "rgba(0,0,0,0)",
                            "plot_bgcolor": "rgba(0,0,0,0)",
                            "legend":{"font": {"color": "darkgray"}, "orientation": "h", "x": 0, "y": 1.1},
                            "xaxis": dict(
                                showline=False, showgrid=False, zeroline=False, title='Time(s)', color = "darkgray", gridcolor='rgb(255,255,255)'
                            ),
                            "yaxis": dict(
                                showgrid=False, showline=False, zeroline=False, title='Voltage(V)', color = "darkgray", gridcolor='rgba(255,255,255,255)', range=[0,3.3]
                            ),
                            "autosize": True,
                        },
                        
                "Osci_layout":{
                            "title": "Voltage Data",
                            "font": dict(color="darkgray"),
                            "paper_bgcolor": "rgba(0,0,0,0)",
                            "plot_bgcolor": "rgba(0,0,0,0)",
                            "legend":{"font": {"color": "darkgray"}, "orientation": "h", "x": 0, "y": 1.1},
                            "xaxis": dict(
                                showline=False, showgrid=False, zeroline=False, title='Points', color = "darkgray", ticks="inside", range=[0,1019]
                            ),
                            "yaxis": dict(
                                showgrid=False, showline=False, zeroline=False, title='Voltage(V)', color = "darkgray", range=[0,3.3]
                            ),
                            # "height": 700, # in px
                            "autosize": True,
                        }
                
                }

def set_osci_specs(spec_params, v_ratio, ucl, lcl, tucl, tlcl , fucl, tucl_chk, tlcl_chk, fucl_chk, channel):
    
    if channel == 1:
        spec_params['osci']['channel-1']['v_ratio']=v_ratio
        spec_params['osci']['channel-1']['ucl']=np.around(ucl/1000,3)
        spec_params['osci']['channel-1']['lcl']=np.around(lcl/1000,3)
        spec_params['osci']['channel-1']['trv']=np.around(tucl/1000,3)
        spec_params['osci']['channel-1']['tfv']=np.around(tlcl/1000,3)
        spec_params['osci']['channel-1']['fv']=np.around(fucl/1000,3)
        spec_params['osci']['channel-1']['tucl_chk']=tucl_chk
        spec_params['osci']['channel-1']['tlcl_chk']=tlcl_chk
        spec_params['osci']['channel-1']['fucl_chk']=fucl_chk
        
    elif channel == 2:
        spec_params['osci']['channel-2']['v_ratio']=v_ratio
        spec_params['osci']['channel-2']['ucl']=np.around(ucl/1000,3)
        spec_params['osci']['channel-2']['lcl']=np.around(lcl/1000,3)
        spec_params['osci']['channel-2']['trv']=np.around(tucl/1000,3)
        spec_params['osci']['channel-2']['tfv']=np.around(tlcl/1000,3)
        spec_params['osci']['channel-2']['fv']=np.around(fucl/1000,3)
        spec_params['osci']['channel-2']['tucl_chk']=tucl_chk
        spec_params['osci']['channel-2']['tlcl_chk']=tlcl_chk
        spec_params['osci']['channel-2']['fucl_chk']=fucl_chk
        
    elif channel == 3:
        spec_params['osci']['channel-3']['v_ratio']=v_ratio
        spec_params['osci']['channel-3']['ucl']=np.around(ucl/1000,3)
        spec_params['osci']['channel-3']['lcl']=np.around(lcl/1000,3)
        spec_params['osci']['channel-3']['trv']=np.around(tucl/1000,3)
        spec_params['osci']['channel-3']['tfv']=np.around(tlcl/1000,3)
        spec_params['osci']['channel-3']['fv']=np.around(fucl/1000,3)
        spec_params['osci']['channel-3']['tucl_chk']=tucl_chk
        spec_params['osci']['channel-3']['tlcl_chk']=tlcl_chk
        spec_params['osci']['channel-3']['fucl_chk']=fucl_chk
    
    
    
    return spec_params




def build_osci_chart():
    return html.Div(className='row', id = 'osci-chart-div',
                     children = [
                        dcc.Graph(id='live-graph', figure = {
                                                            'data' : [
                                                                go.Scatter(
                                                                x = np.array([]),
                                                                y = np.array([]),
                                                                mode = "lines",
                                                                name = "bauds"
                                                                )
                                                            ],
                                                            
                                                            'layout' : FIGURE_FORMAT['Osci_layout']
                                                            },
                                                    config = {'displayModeBar':True, 'displaylogo':False, 'scrollZoom': True, 'modeBarButtonsToRemove':['autoScale2d']},
                                                        ),
                        dcc.Interval(id = 'interval-component', interval = SOFTWARE_SPEED, n_intervals = 0, disabled = True)
                
            ])



def build_DA_chart():
    return html.Div(className='row',
                    id = 'da-chart-div',
                     children = [
                        dcc.Graph(id='live-2-graph', figure = {
                                                            'data' : [
                                                                go.Scatter(
                                                                x = np.array([]),
                                                                y = np.array([]),
                                                                mode = "lines",
                                                                name = "Data"
                                                                )
                                                            ],
                                                            
                                                            'layout' : FIGURE_FORMAT['DA_layout']
                                                            },
                                                    config = {'displayModeBar':True, 'displaylogo':False, 'scrollZoom': True, 'modeBarButtonsToRemove':['autoScale2d']},
                                                        ),
                                                        
                ])


                    
                    