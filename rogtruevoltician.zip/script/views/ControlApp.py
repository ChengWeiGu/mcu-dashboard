import dash
import numpy as np
import time

from dash.dependencies import Input, Output, State
import dash_core_components as dcc
import dash_html_components as html
import dash_daq as daq
import dash_bootstrap_components as dbc
import dash_table


from script.views.TableApp import build_osci_statistic_list
import script.views.ChartApp as chart_app


CONTROLL_LIMIT = {
                  '3': [3000*0.95,3000*1.05], #[LCL, UCL]
                  '5': [5000*0.95,5000*1.05],
                  '12': [12000*0.95,12000*1.05]
                 }



SAMPLE_RATE = {
                '0.68': [0x62,0x70,0x73,0x60,0xE3,0x16,0x00], # '0x16E360' = 1500kpbs = 1.5Mbps (0.68ms)
                '0.75': [0x62,0x70,0x73,0x80,0xc0,0x14,0x00], # '0x14C080' = 1360kbps = 1.36Mbps (0.75ms) 
                '1.0': [0x62,0x70,0x73,0x60,0x90,0x0F,0x00], # '0xF9060' = 1020kbps = 1.02Mbps (1ms)
                '1.5': [0x62,0x70,0x73,0x10,0x68,0x0A,0x00], # '0xA6810' = 682kbps = 0.682 Mbps (1.495ms)
                '2.0': [0x62,0x70,0x73,0x30,0xc8,0x07,0x00], # '0x7C830' = 510k = 0.51M (2 ms)
                '5.0': [0x62,0x70,0x73,0xE0,0x1c,0x03,0x00], # '0x31CE0' = 204k = 0.204M (5 ms)
                '8.0': [0x62,0x70,0x73,0x0c,0xF2,0x01,0x00], # '0x1F20C' = 127.5k (8ms)
                '10.0': [0x62,0x70,0x73,0x70,0x8E,0x01,0x00], # '0x18E70' = 102k (10 ms)
                '20.0': [0x62,0x70,0x73,0x38,0xc7,0x00,0x00], # '0xc738' = 51k (20 ms)
                '30.0': [0x62,0x70,0x73,0xD0,0x84,0x00,0x00], # '0x84D0' = 34k (30 ms)
                '40.0': [0x62,0x70,0x73,0x9C,0x63,0x00,0x00], # '0x639C' = 25.5k (40 ms)
                '50.0': [0x62,0x70,0x73,0xB0,0x4F,0x00,0x00], # '0x4FB0' = 20.4k (50 ms)
                '100.0': [0x62,0x70,0x73,0xD8,0x27,0x00,0x00], # '0x27D8' = 10.2k (100 ms)
                '200.0': [0x62,0x70,0x73,0xEC,0x13,0x00,0x00], # '0x13EC' = 5.1k (200 ms)
                '500.0':[0x62,0x70,0x73,0xF8,0x07,0x00,0x00], # '0x7F8' = 2.04 kHz = 2040 Hz (500ms)
                '1000.0':[0x62,0x70,0x73,0xFC,0x03,0x00,0x00] # '0x3FC' = 1.02 kHz = 1020 Hz (1000ms)
                }


def build_import_components():
    
    return html.Div(className='row',children = 
            [
                
                html.Div(className='three columns', children = [dbc.Button('Import', id = 'upload-2-button', n_clicks = 0, disabled = True)]),
                html.Div(className='nine columns',children = dcc.Input(id = "filename-2-input", type = "text", placeholder="Import a file", readOnly = True ,disabled = False, style = {'float': 'left',"margin-left": "0.5em"})),
                
            ], style={"margin-top": "0.8em","margin-left": "1em"})
            


def build_select_folder_components():
    
    return html.Div(className='row',children = 
            [
                
                html.Div(className='three columns',children = dbc.Button('Open', id = 'openfolder-2-button', n_clicks = 0, disabled = True)),
                html.Div(className='nine columns',children = dcc.Input(id = "folder-2-input", type = "text", placeholder="Select a folder, default: \".\\data\"", readOnly = True ,disabled = False, style = {'float': 'left', "margin-left": "0.5em"})),
                
            ], style={"margin-top": "0.8em","margin-left": "1em"})
    


def build_DA_ctrl_btn():
    
    return html.Div(id = 'control-btns-div',
                    className='row',
                    children = [
                                html.Div(className='row',
                                        children = [
                                            html.Div(className='three columns',   children = dbc.Button('Record', id = 'start-2-button', n_clicks = 0, disabled = True)),
                                            html.Div(className='three columns', children = dbc.Button('Clear', id = 'reset-2-button', n_clicks = 0, disabled = True)),
                                            html.Div(className='three columns', id = "loading-2-output", children = "Initialize..."),
                                            html.Div(className='three columns', id = "timer-2-output", children = ""),
                                            dcc.Interval(id = 'timer-interval', interval = 100, n_intervals = 0, disabled = False),
                                            
                                        ], style={"margin-top": "1em","margin-left": "1em"}),
                                build_import_components(),
                                build_select_folder_components(),
                                ]
                    )
    
                    
                    
def build_DA_rs_selection():
    return html.Div(className='row',
            children = [
                        html.Div(className = 'four columns', children = "MCU Sample Rate: ",id='Rs-2-label', style={'font-size':'15px', 'font-weight':'bold', "text-align":"center","margin-top": "0.25em"}),
                        html.Div(className = 'eight columns',
                                children = dcc.Dropdown(id='dropdown-2-Rs',
                                                        options=[
                                                            # {'label': '1ms(1.02MHz)', 'value': 1.0},
                                                            # {'label': '2ms(510kHz)', 'value': 2.0},
                                                            # {'label': '5ms(204kHz)', 'value': 5.0},
                                                            # {'label': '10ms(102kHz)', 'value': 10.0},
                                                            # {'label': '20ms(51kHz)', 'value': 20.0},
                                                            {'label': '30ms(34kHz)', 'value': 30.0},
                                                            {'label': '40ms(25.5kHz)', 'value': 40.0},
                                                            {'label': '50ms(20.4kHz)', 'value': 50.0},
                                                            {'label': '100ms(10.2kHz)', 'value': 100.0},
                                                        ],
                                                        value=100.0,
                                                        clearable=False
                                                        )
                        ),
                    ], style = {"margin-top": "1.5em","margin-left": "1em"})
                    

def build_DA_volt_selection():
    return html.Div(className='row',
            children = [
                        html.Div(className = 'four columns', children = "Magnitude: ",id='dropdown-DA-label', style={'font-size':'15px', 'font-weight':'bold', "text-align":"center","margin-top": "0.25em"}),
                        html.Div(className = 'eight columns',
                                children = [
                                            dcc.Dropdown(id='dropdown-DA-voltage',
                                                        options=[
                                                            {'label': '3.0V', 'value': 3},
                                                            {'label': '5.0V', 'value': 5},
                                                            {'label': '12.0V', 'value': 12}
                                                        ],
                                                        value=3,
                                                        clearable=False
                                                        )
                                        ]),
                        
                        
                    ], style = {"margin-top": "1em","margin-left": "1em"})


def build_DA_mode_selection():
    return html.Div(className='row',
            children = [
                        html.Div(className = 'four columns',
                                children = [
                                            html.Div(children = 'Linewidth:', style = {'margin-top':'0.3em','font-size':'15px', 'font-weight':'bold'}, className="four columns"),
                                            html.Div(daq.NumericInput(id="DA-linewidth", className="setting-input",min=0.3, max=5, value=0.85), className="five columns")
                                            ]
                        
                        ),
                        
                        
                    ], style = {"margin-top": "1em","margin-left": "1em"})
                    
                    
                    
def build_value_setter_line(line_id, first_id, second_id,  first_child, second_child, style_customed=True):
    return html.Div(
        id=line_id,
        children=[
            html.Label(id = first_id, children = first_child, className="five columns", style={'font-size':'15px', 'font-weight':'bold', "text-align":"center","margin-top": "0.5em","margin-left": "0.5em"} if style_customed else {}),
            html.Div(id = second_id , children = second_child, className="five columns",style={'font-size':'15px'}),
        ],
        className="row",
    )


def build_DA_numeric_control_limit():
    
    ucl=int(chart_app.SPEC_PARAMS['DA']['ucl']*1000)
    lcl=int(chart_app.SPEC_PARAMS['DA']['lcl']*1000)
    

    return html.Div(id = 'DACtrlLmit-Div',
                    children=[  
                    
                                build_value_setter_line("value-setter-panel-header","da-header-11","da-header-12","Function","Set value (mV)",style_customed=False),
                                build_value_setter_line("value-setter-panel-ucl","da-ucl-21","da-ucl-22","Upper limit: ",daq.NumericInput(id="ud_ucl_input", className="setting-input", size=200,min=0, max=9999999, value=ucl),style_customed=True),
                                build_value_setter_line("value-setter-panel-lcl","da-lcl-31","da-lcl-32","Lower limit: ",daq.NumericInput(id="ud_lcl_input", className="setting-input", size=200,min=0, max=9999999, value=lcl),style_customed=True),
                                
                        ])
                        
def build_DA_control_limit():
    return html.Div(id = 'DACtrlLmit-Div', className = 'row',
                    children=[
                                html.Div(className="nine columns", children = build_DA_numeric_control_limit()),
                                html.Div(className="three columns", children = dbc.Button('Update', id = 'da_limit_update_btn', n_clicks = 0, disabled = True)),
                                
                        ],style={'margin-top':'1.5em'})
                        
                                             
                        
def build_osci_ctrl_btn():
    return html.Div(id = 'control-oscibtns-div',
                    className='row',
                    children = [
                        html.Div(className='three columns',   children = dbc.Button('Start', id = 'start_btn', n_clicks = 0, style={})),
                        html.Div(className='three columns', children = dbc.Button('Stop', id = 'stop_btn', n_clicks = 0)),
                        html.Div(className='three columns', children = dbc.Button('Clear', id = 'reset_btn', n_clicks = 0)),
                        html.Div(className='three columns', children="Stopping...", id = 'runing_state_text'),
                    ], style={"margin-top": "1em","margin-left": "0.5em"})
                    
                    
                    
                    
                    
def build_osci_rs_selection():
    return html.Div(className='row',
            children = [
                        html.Div(className = 'four columns', children = "MCU Sample Rate: ",id='Rs-label', style={'font-size':'15px', 'font-weight':'bold', "text-align":"center","margin-top": "0.25em"}),
                        html.Div(className = 'eight columns',
                                children = dcc.Dropdown(id='dropdown-Rs',
                                                        options=[
                                                            # {'label': '1ms(1.02MHz)', 'value': 1.0},
                                                            # {'label': '2ms(510kHz)', 'value': 2.0},
                                                            # {'label': '5ms(204kHz)', 'value': 5.0},
                                                            # {'label': '10ms(102kHz)', 'value': 10.0},
                                                            # {'label': '20ms(51kHz)', 'value': 20.0},
                                                            {'label': '30ms(34kHz)', 'value': 30.0},
                                                            {'label': '40ms(25.5kHz)', 'value': 40.0},
                                                            {'label': '50ms(20.4kHz)', 'value': 50.0},
                                                            {'label': '100ms(10.2kHz)', 'value': 100.0},
                                                            # {'label': '200ms(5.1kHz)', 'value': 200.0},
                                                            # {'label': '500ms(2040Hz)', 'value': 500.0}
                                                        ],
                                                        value=100.0,
                                                        clearable=False,
                                                        )),           
                    ], style = {"margin-top": "1.5em","margin-left": "1em"})            


def build_osci_ch_selection():
    return html.Div(className='row',
            children = [
                        html.Div(className = 'three columns', children = "Current Channel: ",id='Channel-1-label',  style={'font-size':'15px', 'font-weight':'bold', "text-align":"center","margin-top": "0.4em"}),
                        html.Div(className = 'five columns',
                                children = [
                                            html.Div(children = dcc.Checklist(id = 'channel_choice',
                                                                    options=[
                                                                            {'label': 'Channel-1', 'value': 1},
                                                                            {'label': 'Channel-2', 'value': 2},
                                                                            {'label': 'Channel-3', 'value': 3}
                                                                    ],
                                                                    value=[1],
                                                                    labelStyle={'display': 'inline-block'}
                                                                ), style = {'margin-top':'0.1em', 'margin-left':'-3.0em'}
                                                ),
                                            ]
                        
                        ),
                        
                        html.Div(className = 'four columns',
                                children = [
                                            html.Div(children = 'Linewidth:', style = {'margin-top':'0.3em','font-size':'15px', 'font-weight':'bold'}, className="four columns"),
                                            html.Div(daq.NumericInput(id="osci-linewidth", className="setting-input",min=0.3, max=5, value=0.85), className="five columns")
                                            ]                       
                        ),                
                    ], style = {"margin-top": "1em","margin-left": "1em"}) 
                    
                    
                    
                    
def build_osci_volt_selection(channel):
    
    v_ratio = chart_app.SPEC_PARAMS['osci'][f'channel-{channel}']['v_ratio']
    
    return html.Div(className='row',
            children = [
                        html.Div(id  = 'dropdown-osci-label',className = 'four columns', children = "Magnitude: ", style={'font-size':'15px', 'font-weight':'bold', "text-align":"center","margin-top": "0.3em"}),
                        html.Div(className = 'eight columns',
                                children = [
                                            dcc.Dropdown(id=f'dropdown-{channel}-voltage',
                                                        options=[
                                                            {'label': '3.0V', 'value': 3},
                                                            {'label': '5.0V', 'value': 5},
                                                            {'label': '12.0V', 'value': 12}
                                                        ],
                                                        value=v_ratio,
                                                        clearable=False
                                                        )
                                        ]),                 
                    ], style = {"margin-top": "1em","margin-left": "1em"})
          
          

def build_value_setter_osci_line(line_id, first_id, second_id, third_id , first_child, second_child, third_child, update_style = {}):
    
    _style = {'font-size':'15px' if len(first_child) < 15 else '14px', 'font-weight':'bold', "text-align":"center", "margin-top":"0.5rem"}
    _style.update(update_style)
    
    return html.Div(
        id=line_id,
        children=[
            html.Div(id = first_id, children=first_child, className="four columns",  style=_style),
            html.Div(id = second_id, children=second_child, className="four columns", style={"text-align":"center"}),
            html.Div(id = third_id, children=third_child, className="four columns"),
        ],
        className="row",
    )


def build_trigger_component(channel,name):
    
    chk_list = chart_app.SPEC_PARAMS['osci'][f'channel-{channel}'][f'{name}_chk'] 
    
    return dcc.Checklist(id = f'trigger-{name}{channel}-checklist',
                        options=[
                                {'label': 'Trigger', 'value': 1}
                        ],
                        value=chk_list)


def build_filter_component(channel):

    chk_list = chart_app.SPEC_PARAMS['osci'][f'channel-{channel}']['fucl_chk']
    
    return dcc.Checklist(id = f'filter-{channel}-checklist',
                        options=[
                                {'label': 'Filter', 'value': 1}
                        ],
                        value=chk_list,
                        labelStyle={'display': 'inline-block'})
                        


def build_osci_control_limit(channel):
    
    ucl=int(chart_app.SPEC_PARAMS['osci'][f'channel-{channel}']['ucl']*1000)
    lcl=int(chart_app.SPEC_PARAMS['osci'][f'channel-{channel}']['lcl']*1000)
    tucl=int(chart_app.SPEC_PARAMS['osci'][f'channel-{channel}']['trv']*1000)
    tlcl=int(chart_app.SPEC_PARAMS['osci'][f'channel-{channel}']['tfv']*1000)
    fucl=int(chart_app.SPEC_PARAMS['osci'][f'channel-{channel}']['fv']*1000)
    
    
    return html.Div(id = 'OSCICtrlLmit-Div',
                    children=[
                                
                                build_value_setter_osci_line(f"value-setter-osci-panel-header",f"osci-header-11", f"osci-header-12", f"osci-header-13","Function","Set value (mV)","OutPercentage(%)", update_style = {"margin-top":"0rem",'font-size':'15px'}),
                                build_value_setter_osci_line(f"value-setter-osci-panel-ucl",f"osci-ucl-21",f"osci-ucl-22",f"osci-ucl-23","Higher than: ",daq.NumericInput(id=f"ud_ucl_osci_input-{channel}", className="setting-input", size=200,min=0, max=9999999, value=ucl),"--"),
                                build_value_setter_osci_line(f"value-setter-osci-panel-lcl",f"osci-lcl-31",f"osci-lcl-32",f"osci-lcl-33","Lower than: ",daq.NumericInput(id=f"ud_lcl_osci_input-{channel}", className="setting-input", size=200,min=0, max=9999999, value=lcl),"--"),
                                build_value_setter_osci_line(f"value-setter-osci-panel-tucl",f"osci-tucl-41",f"osci-tucl-42",f"osci-tucl-43","Trigger Rising Value: ",daq.NumericInput(id=f"trigger-ucl-numeric-{channel}", size=200, min=0, max=9999999, value=tucl),build_trigger_component(channel,"tucl")),
                                build_value_setter_osci_line(f"value-setter-osci-panel-tlcl",f"osci-tlcl-51",f"osci-tlcl-52",f"osci-tlcl-53","Trigger Falling Value: ",daq.NumericInput(id=f"trigger-lcl-numeric-{channel}", size=200, min=0, max=9999999, value=tlcl),build_trigger_component(channel,"tlcl")),
                                build_value_setter_osci_line(f"value-setter-osci-panel-fucl",f"osci-fucl-61",f"osci-fucl-62",f"osci-fucl-63","Filter Greater Than: ",daq.NumericInput(id=f"filter-ucl-numeric-{channel}", size=200, min=0, max=9999999, value=fucl),build_filter_component(channel)),
                        ])



def build_osci_channel_pannel(channel):
    return html.Div(id = 'Channel-content-panel',
                    children=[
                                build_osci_volt_selection(channel),
                                build_osci_control_limit(channel),
                                build_osci_statistic_list(channel),
                        ])
    
