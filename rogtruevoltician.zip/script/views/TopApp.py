import dash
import numpy as np
import time

from dash.dependencies import Input, Output, State
import dash_core_components as dcc
import dash_html_components as html
import dash_daq as daq
import dash_bootstrap_components as dbc
import dash_table

import plotly.graph_objs as go
from script.views.ChartApp import build_DA_chart, build_osci_chart
from script.views.TableApp import build_DA_table, build_osci_statistic_list
from script.views.ControlApp import build_DA_ctrl_btn, build_DA_rs_selection, build_DA_volt_selection, build_DA_control_limit, build_DA_mode_selection
from script.views.ControlApp import build_osci_ctrl_btn, build_osci_rs_selection, build_osci_ch_selection, build_osci_channel_pannel


def build_banner():
    return html.Div(
        id="banner",
        className="banner",
        children=[
            html.Div(
                id="banner-text",
                children=[
                    html.H5("ROG True Voltician Dashboard", style={'font-wmaxDataPts': 'bold','font-size':28, 'font-family':'ASUS_ROG'}),
                    html.H6(""),
                    html.Div(id='showtime-div4', children = "", style={'font-wmaxDataPts': 'bold','font-size':16}),
                    dcc.Interval(id = 'date-interval', interval = 1000, n_intervals = 0, disabled = False),
                ],
            ),
            html.Div(
                id="banner-logo",
                children=[
                    html.Button(id="learn-more-button", children="LEARN MORE", n_clicks=0),
                    # html.Img(id='logo',src='assets/favicon.ico')
                ],
            ),
        ],
    )


def build_tabs():
    return html.Div(
        id="tabs",
        className="tabs",
        children=[
            dcc.Tabs(
                id="app-tabs",
                value="tab1", # it can control which tab will show up at the begining 
                className="custom-tabs",
                children=[
                    dcc.Tab(
                        id="OSCI-tab",
                        label="Oscilloscope System",
                        value="tab1",
                        className="custom-tab",
                        selected_className="custom-tab--selected",
                        style={'font-weight': 'bold','font-size':18}
                    ),
                    dcc.Tab(
                        id="DA-tab",
                        label="Data Analysis",
                        value="tab2",
                        className="custom-tab",
                        selected_className="custom-tab--selected",
                        style={'font-weight': 'bold','font-size':18}
                    ),
                ],
            )
        ],
    )


def build_osci_channel_tabs():
    return html.Div(
        id="channel-tabs",
        className="tabs",
        children=[
            dcc.Tabs(
                id="app-channel-tabs",
                value="tab1", # it can control which tab will show up at the begining 
                className="custom-tabs",
                children=[
                    dcc.Tab(
                        id="channel-1-tab",
                        label="Channel-1",
                        value="tab1",
                        className="custom-tab",
                        selected_className="custom-tab--selected",
                        style={'font-weight': 'bold','font-size':14}
                    ),
                    
                    dcc.Tab(
                        id="channel-2-tab",
                        label="Channel-2",
                        value="tab2",
                        className="custom-tab",
                        selected_className="custom-tab--selected",
                        style={'font-weight': 'bold','font-size':14}
                    ),
                    
                    dcc.Tab(
                        id="channel-3-tab",
                        label="Channel-3",
                        value="tab3",
                        className="custom-tab",
                        selected_className="custom-tab--selected",
                        style={'font-weight': 'bold','font-size':14}
                    ),
                    
                ],
            )
        ],
    )



def generate_section_banner(title):
    return html.Div(className="section-banner", children=title)
    

def build_osci_panel():
    return html.Div(
        id="top-section-oscicontainer",
        className="row",
        children=[
            # DA Charts
            html.Div(
                id="mcu-figure-oscisession",
                className="eight columns",
                children=[
                    generate_section_banner(""),
                    html.Div(
                        id="control-chart-oscicontainer",
                        children=[
                            build_osci_ch_selection(),
                            build_osci_chart(),
                        ],style={"height": "100%", "width": "100%"}
                    ),
                ],
            ),
            # parameter panel
            html.Div(
                id="mcu-param-oscipanel",
                className="four columns",
                children=[
                    generate_section_banner(""),
                    build_osci_ctrl_btn(),
                    build_osci_rs_selection(),
                    build_osci_channel_tabs(),
                    build_osci_channel_pannel(1), # the arg "1" has two meanings. e.g. just component order or channel order
                ],
            ),
        ],
    )


def build_DA_sub_panel():
    return html.Div(
        id="top-section-dacontainer",
        className="row",
        children=[
            # DA Charts
            html.Div(
                id="mcu-figure-dasession",
                className="eight columns",
                children=[
                    generate_section_banner(""),
                    build_DA_mode_selection(),
                    html.Div(
                        id="control-chart-dacontainer",
                        children=[
                            build_DA_chart(),
                        ],style={"height": "100%", "width": "100%"}
                    ),
                ],
            ),
            # parameter panel
            html.Div(
                id="mcu-param-dapanel",
                className="four columns",
                children=[
                    generate_section_banner(""),
                    build_DA_ctrl_btn(),
                    build_DA_rs_selection(),
                    build_DA_volt_selection(),
                    build_DA_control_limit(),
                ],
            ),
        ],
    )

def build_DA_panel():
    return html.Div(
            id="tables-container",
            children=[
                build_DA_sub_panel(),
                build_DA_table(),
            ],
        )
        
        
        