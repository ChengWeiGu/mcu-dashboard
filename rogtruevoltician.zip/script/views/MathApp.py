import numpy as np



def check_arr_len(arr):
    if len(arr) > 0:
        return True
    else:
        return False


def calculate_out_of_specs(y_arr,UCL,LCL,approx_num = 2):
    outPercentage_ucl = np.around(np.sum(y_arr > UCL)/len(y_arr)*100, decimals = approx_num)
    outPercentage_lcl = np.around(np.sum(y_arr < LCL)/len(y_arr)*100, decimals = approx_num)
    
    return outPercentage_ucl, outPercentage_lcl
    

def calculate_osci_features(y_arr,UCL,LCL,approx_num = 2):
    
    outPercentage_ucl = np.around(np.sum(y_arr > UCL)/len(y_arr)*100, decimals = approx_num)
    outPercentage_lcl = np.around(np.sum(y_arr < LCL)/len(y_arr)*100, decimals = approx_num)
    
    max_val = np.around(y_arr.max(), decimals = approx_num)
    min_val = np.around(y_arr.min(), decimals = approx_num)
    ave_val = np.around(y_arr.mean(), decimals = approx_num)
    
    return outPercentage_ucl, outPercentage_lcl, max_val, min_val, ave_val
    


def calculate_DA_features(y_arr,UCL,LCL,approx_num = 4):
    
    max_val = np.around(y_arr.max(), decimals = approx_num)
    min_val = np.around(y_arr.min(), decimals = approx_num)
    FD_val = np.around(y_arr.max()-y_arr.min(), decimals = approx_num)
    ave_val = np.around(y_arr.mean(), decimals = approx_num)
    rms_val = np.around(np.sqrt((y_arr**2).sum()/len(y_arr)), decimals = approx_num)
    std_val = np.around(np.sqrt(((y_arr-ave_val)**2).sum()/len(y_arr)), decimals = approx_num)
    cv_percentage = np.around(std_val/ave_val*100, decimals = approx_num) if (ave_val != 0) else 0
    outPercentage = np.around(np.sum((y_arr > UCL)|(y_arr < LCL))/len(y_arr)*100, decimals = approx_num)
    
    return max_val, min_val, FD_val, ave_val, rms_val, std_val, cv_percentage, outPercentage