import numpy as np
import time
import datetime
import pandas as pd
from os.path import dirname, basename, join, splitext, getsize
import dash
from dash.dependencies import Input, Output, State
import dash_core_components as dcc
import dash_html_components as html
import dash_daq as daq
import dash_bootstrap_components as dbc
import dash_table
import plotly.graph_objs as go
from script.views.TopApp import build_banner, build_tabs, build_DA_panel, build_osci_panel
from script.views.ControlApp import SAMPLE_RATE, CONTROLL_LIMIT, build_osci_channel_pannel
from script.views.TableApp import TABLE_FORMAT
from script.views.ChartApp import FIGURE_FORMAT, set_osci_specs
import script.views.ChartApp as chart_app
from script.views.MathApp import calculate_out_of_specs, calculate_osci_features, calculate_DA_features, check_arr_len
from script.mcu import MCUF403A
from tkinter import Tk, filedialog
from script.logger import output_log
from script.dialogs import open_folder_dialog_tk, upload_by_filedialog_tk, save_by_filedialog_tk
from script.web_controller import open_web_by_learn_more_btn



def export_table(filename, table_data):
    table_filename = dirname(filename) + '/' + basename(filename).split('.')[0] + '-StatTable.csv'
    columns = table_data[0].keys()
    
    merge_data = np.array([])
    for row, dict_data in enumerate(table_data):
        _data = np.array(list(dict_data.values()))
        merge_data = np.append(merge_data,_data)
    
    merge_data = merge_data.reshape(3,-1)
    pd.DataFrame(merge_data,columns = columns).to_csv(table_filename, index = False)
    



class WaveFormApp:
    
    def __init__(self):
        
        # page-1 parameters
        self.mcu_f403a = MCUF403A()
        self.current_stop_clicks=0
        self.last_stop_clicks=0
        self.current_start_clicks=0
        self.last_start_clicks=0
        self.current_reset_click=0
        self.last_reset_click=0
        self.current_channel_tab='tab1'
        self.last_channel_tab='tab1'
        self.n_count = 0 # used to suppress the tab-tab switch delay when writting specs
        
        # the following features are computed and will be displayed on the oscilloscope panel
        self.output_ucl_percent, self.output_lcl_percent, self.output_max, self.output_min, self.output_ave = ["--"]*5
        self.reset_osci_stat_data()
        self.change_spec_enable = True
        self.runing_state_ctrl=False
        
        # page-2 parameters:
        self.y_upload_arr_list = [np.array([])]*3 # used for statistic calculation of uploading
        self.output_string = "" # shown in the input component
        self.upload_state=True # if file is uploaded and processed successfully, gives True
        self.data1, self.data2, self.data3 = [b'']*3 # record the DA data
        self.folder_path = './data/' # default
        self.n_timer = 0
        self.fig_data_list_no_limits = [] # used for updating control limits
        self.control_limit_x_max = 0 # used for updating control limits
        self.last_chart_data_from = 'record' # the last chart data from 'import' or 'record'
        
        
        self.app = dash.Dash(__name__, title = 'ROG True Voltician')
        
        self.web_port = self.mcu_f403a.parameters.web_port
        self.web_host = '127.0.0.1'
         
        
        self.app.layout = html.Div(
            id="big-app-container",
            children=[
                build_banner(),
                html.Div(
                    id="app-container",
                    children=[
                        build_tabs(),
                        # Main app
                        html.Div(id="app-content"),
                        html.Div(id='hidden-top-div1', style={'display':'none'}), # this div does nothing but used for "Learn more button"
                        html.Div(id='hidden-osci-div1', style={'display':'none'}), # this div does nothing but used for re-layout control (osci)
                        html.Div(id='hidden-DA-div1', style={'display':'none'}), # this div does nothing but used for record control/trigger (DA)
                        html.Div(id='hidden-DA-div2', style={'display':'none'}), # this div does nothing but used for upload trigger (DA)
                        html.Div(id='hidden-DA-div3', style={'display':'none'}), # this div does nothing but used for clear trigger (DA)
                        html.Div(id='hidden-DA-div4', style={'display':'none'}), # this div does nothing but used for update trigger (DA)
                        html.Div(id='hidden-DA-div5', style={'display':'none'}), # this div does nothing but used for export table data (DA)
                    ]
                ),  
            ])
        
        
        @self.app.callback(
            Output("showtime-div4", "children"),
            [Input('date-interval', "n_intervals")])
        def show_time(n_intervals):
            return "DateTime : " + datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')
        
        
        # learn more button
        @self.app.callback(
            Output("hidden-top-div1", "style"),
            [Input('learn-more-button', "n_clicks")], prevent_initial_call = True)
        def access_asus_web(btn1):
            if btn1 > 0:
                open_web_by_learn_more_btn()
            else:
                pass
            
            return {'display':'none'}
        
        
        
        @self.app.callback(
            Output("app-content", "children"),
            [Input("app-tabs", "value")])
        def render_tab_content(tab_switch):
            if tab_switch == "tab1":
                self.mcu_f403a.collect_long_data_enable = False # auto stop when switch sys from tab2 to tab1
                self.mcu_f403a.set_rs(system = 'osci')
                self.mcu_f403a.connect_mcu()
                return build_osci_panel()
            elif tab_switch == "tab2":
                self.runing_state_ctrl = False # auto stop when switch sys from tab1 to tab2
                self.mcu_f403a.disconnect_mcu()
                self.mcu_f403a.set_rs(system = 'DA')
                return build_DA_panel()
        
        
        @self.app.callback(
            [Output('dropdown-1-voltage','value'),
            Output('ud_ucl_osci_input-1','value'),
            Output('ud_lcl_osci_input-1','value'),
            Output('trigger-ucl-numeric-1', 'value'),
            Output('trigger-lcl-numeric-1','value'),
            Output('filter-ucl-numeric-1','value'),
            Output('trigger-tucl1-checklist','value'),
            Output('trigger-tlcl1-checklist','value'),
            Output('filter-1-checklist','value')],
            [Input("app-channel-tabs", "value")])
        def render_channel_tab_content(tab_switch):
            
            channel = tab_switch[-1]
            volt_ratio=chart_app.SPEC_PARAMS['osci']['channel-'+channel]['v_ratio']
            ucl=int(chart_app.SPEC_PARAMS['osci']['channel-'+channel]['ucl']*1000)
            lcl=int(chart_app.SPEC_PARAMS['osci']['channel-'+channel]['lcl']*1000)
            tucl=int(chart_app.SPEC_PARAMS['osci']['channel-'+channel]['trv']*1000)
            tlcl=int(chart_app.SPEC_PARAMS['osci']['channel-'+channel]['tfv']*1000)
            fucl=int(chart_app.SPEC_PARAMS['osci']['channel-'+channel]['fv']*1000)
            tucl_chk=chart_app.SPEC_PARAMS['osci']['channel-'+channel]['tucl_chk']
            tlcl_chk=chart_app.SPEC_PARAMS['osci']['channel-'+channel]['tlcl_chk']
            fucl_chk=chart_app.SPEC_PARAMS['osci']['channel-'+channel]['fucl_chk']
            
            return volt_ratio, ucl, lcl, tucl, tlcl, fucl, tucl_chk, tlcl_chk, fucl_chk
        
        
        
        
        #oscilloscope system
        @self.app.callback(
              [Output('live-graph', 'figure'),
              Output('interval-component','interval'),
              Output('runing_state_text','children'),
              Output('interval-component','disabled'),
              Output('osci-ucl-23','children'), #OutPercentage for ucl
              Output('osci-lcl-33','children'), # OutPercentage for lcl
              Output('max-val-tag-1','children'),
              Output('min-val-tag-1','children'),
              Output('ave-val-tag-1','children')],
              [Input('interval-component', 'n_intervals'),
              Input('start_btn', 'n_clicks'),
              Input('stop_btn', 'n_clicks'),
              Input('reset_btn', 'n_clicks'),
              Input("app-channel-tabs", "value")],
              [State('channel_choice', 'value'),
              State('dropdown-Rs','value'),
              State('dropdown-1-voltage','value'),
              State('ud_ucl_osci_input-1','value'),
              State('ud_lcl_osci_input-1','value'),
              State('trigger-ucl-numeric-1', 'value'),
              State('trigger-lcl-numeric-1','value'),
              State('filter-ucl-numeric-1','value'),
              State('trigger-tucl1-checklist','value'),
              State('trigger-tlcl1-checklist','value'),
              State('filter-1-checklist','value'),
              State('osci-linewidth','value')])
              
        def update_osci_graph(n_intervals, start_clicks, stop_clicks, reset_clicks , tab_switch, channel_list , rs_value, v_ratio, ucl, lcl, tucl, tlcl , fucl, tucl_chk, tlcl_chk, fucl_chk, linewidth):
            
            
            self.last_start_clicks = self.current_start_clicks
            self.current_start_clicks = start_clicks
            self.last_stop_clicks = self.current_stop_clicks
            self.current_stop_clicks = stop_clicks
            self.last_reset_click = self.current_reset_click
            self.current_reset_click = reset_clicks
            self.last_channel_tab = self.current_channel_tab
            self.current_channel_tab=tab_switch
            
            if (self.current_stop_clicks > self.last_stop_clicks):
                self.runing_state_ctrl = False
                
            elif self.current_start_clicks > self.last_start_clicks:
                self.runing_state_ctrl = True
                    
            if self.last_channel_tab != self.current_channel_tab:
                self.n_count = 0
                self.change_spec_enable = False
            else:
                self.change_spec_enable = True
                self.n_count += 1
            
            
            ##################################################################################################################################################
            ####################################Before changing the params, user need to click up stop button at first########################################
            ####################################After changing the params, user need to click up start button for runing######################################
            ##########################User should change params channel by channel so that channel-params can be definitely updated###########################
            ##################################################################################################################################################
            
            if self.runing_state_ctrl and self.change_spec_enable and self.n_count > 1:
                current_ind = int(self.current_channel_tab[-1])
                set_osci_specs(chart_app.SPEC_PARAMS, v_ratio, ucl, lcl, tucl, tlcl , fucl, tucl_chk, tlcl_chk, fucl_chk, current_ind)
                
                    
                
            
            self.mcu_f403a.amplify_ratio_c1=chart_app.SPEC_PARAMS['osci']['channel-1']['v_ratio']
            ucl_1=chart_app.SPEC_PARAMS['osci']['channel-1']['ucl']
            lcl_1=chart_app.SPEC_PARAMS['osci']['channel-1']['lcl']
            tucl_1=chart_app.SPEC_PARAMS['osci']['channel-1']['trv']
            tlcl_1=chart_app.SPEC_PARAMS['osci']['channel-1']['tfv']
            fucl_1=chart_app.SPEC_PARAMS['osci']['channel-1']['fv']
            tucl_chk1=chart_app.SPEC_PARAMS['osci']['channel-1']['tucl_chk']
            tlcl_chk1=chart_app.SPEC_PARAMS['osci']['channel-1']['tlcl_chk']
            fucl_chk1=chart_app.SPEC_PARAMS['osci']['channel-1']['fucl_chk']
            
            self.mcu_f403a.amplify_ratio_c2=chart_app.SPEC_PARAMS['osci']['channel-2']['v_ratio']
            ucl_2=chart_app.SPEC_PARAMS['osci']['channel-2']['ucl']
            lcl_2=chart_app.SPEC_PARAMS['osci']['channel-2']['lcl']
            tucl_2=chart_app.SPEC_PARAMS['osci']['channel-2']['trv']
            tlcl_2=chart_app.SPEC_PARAMS['osci']['channel-2']['tfv']
            fucl_2=chart_app.SPEC_PARAMS['osci']['channel-2']['fv']
            tucl_chk2=chart_app.SPEC_PARAMS['osci']['channel-2']['tucl_chk']
            tlcl_chk2=chart_app.SPEC_PARAMS['osci']['channel-2']['tlcl_chk']
            fucl_chk2=chart_app.SPEC_PARAMS['osci']['channel-2']['fucl_chk']
            
            self.mcu_f403a.amplify_ratio_c3=chart_app.SPEC_PARAMS['osci']['channel-3']['v_ratio']
            ucl_3=chart_app.SPEC_PARAMS['osci']['channel-3']['ucl']
            lcl_3=chart_app.SPEC_PARAMS['osci']['channel-3']['lcl']
            tucl_3=chart_app.SPEC_PARAMS['osci']['channel-3']['trv']
            tlcl_3=chart_app.SPEC_PARAMS['osci']['channel-3']['tfv']
            fucl_3=chart_app.SPEC_PARAMS['osci']['channel-3']['fv']
            tucl_chk3=chart_app.SPEC_PARAMS['osci']['channel-3']['tucl_chk']
            tlcl_chk3=chart_app.SPEC_PARAMS['osci']['channel-3']['tlcl_chk']
            fucl_chk3=chart_app.SPEC_PARAMS['osci']['channel-3']['fucl_chk']
            
            ##################################################################################################################################################
            ##################################################################################################################################################
            ##################################################################################################################################################
            
            LCLs = [lcl_1, lcl_2, lcl_3]
            UCLs = [ucl_1, ucl_2, ucl_3]
            
            
            output_interval = self.mcu_f403a.software_speed
            if (float(rs_value) != self.mcu_f403a.software_speed) and self.runing_state_ctrl:
                self.mcu_f403a.software_speed=float(rs_value)
                self.mcu_f403a.disconnect_mcu()
                self.mcu_f403a.set_rs(system = 'osci')
                self.mcu_f403a.connect_mcu()
                self.mcu_f403a.reset_data()
                output_interval = self.mcu_f403a.software_speed
            
            
            
            if self.runing_state_ctrl:
                self.osci_stat_data['n_points']+=1
                
                if self.osci_stat_data['n_points'] > self.osci_stat_data['reset_thr']:
                    self.reset_osci_stat_data()
                
                _chks = [fucl_chk1,fucl_chk2,fucl_chk3]
                filter_thresholds=[fucl_1,fucl_2,fucl_3] # [filter_value_c1, filter_value_c2, filter_value_c3]
                filter_trigger_states = [1 if _chk == [1] else 0 for _chk in _chks] # [c1_enable, c2_enable, c3_enable]
                
                if (self.last_channel_tab == self.current_channel_tab):
                    self.mcu_f403a.collect_single_baud(filter_trigger_states, filter_thresholds) #the filtering function created on 2021/05/06
                else:
                    pass # do not capture data when tabs are switching
                    
                output_state = "Running..."
                output_update_disable=False
            else:
                self.mcu_f403a.stop()
                output_state = "Stopping..."
                output_update_disable=True
            
            
            ########################################reseting#######################################       
            if (self.current_reset_click > self.last_reset_click): # reset acts as clear
                self.output_ucl_percent, self.output_lcl_percent, self.output_max, self.output_min, self.output_ave = [0]*5
                self.mcu_f403a.reset_features()
                self.reset_osci_stat_data()
                output_state = "Clear!"
            ########################################reseting#######################################
                    

            x = self.mcu_f403a.time_list
            fig_data_list = []
            y_arr = np.array([])
            y_arr_list = [self.mcu_f403a.data_list_c1, self.mcu_f403a.data_list_c2, self.mcu_f403a.data_list_c3]
            
            
            
            for ind, y in enumerate(y_arr_list):
                
                self.mcu_f403a.osci_max_list[ind] = np.around(y.max(),4) if len(y) > 0 else -0.5 #y could be 0 size because of filtering
                self.mcu_f403a.osci_min_list[ind] = np.around(y.min(),4) if len(y) > 0 else 15
                self.osci_stat_data[f'order-{ind}']['ave'] = np.append(self.osci_stat_data[f'order-{ind}']['ave'],np.around(y.mean(),4) if len(y) > 0 else 0.0)
                self.mcu_f403a.osci_ave_list[ind] = np.around(self.osci_stat_data[f'order-{ind}']['ave'].mean(),4)
                
                out_percentage_ucl, out_percentage_lcl = calculate_out_of_specs(y,UCLs[ind],LCLs[ind],2) if len(y) > 0 else (0,0)
                self.osci_stat_data[f'order-{ind}']['out_ucl'] = np.append(self.osci_stat_data[f'order-{ind}']['out_ucl'],out_percentage_ucl)
                self.osci_stat_data[f'order-{ind}']['out_lcl'] = np.append(self.osci_stat_data[f'order-{ind}']['out_lcl'],out_percentage_lcl)
                self.mcu_f403a.osci_out_ucl_list[ind] = np.around(self.osci_stat_data[f'order-{ind}']['out_ucl'].mean(),2)
                self.mcu_f403a.osci_out_lcl_list[ind] = np.around(self.osci_stat_data[f'order-{ind}']['out_lcl'].mean(),2)
            
            
            self.mcu_f403a.long_term_max_list = [current_data if long_term_data < current_data else long_term_data for long_term_data, current_data in zip(self.mcu_f403a.long_term_max_list, self.mcu_f403a.osci_max_list)]
            self.mcu_f403a.long_term_min_list = [current_data if long_term_data > current_data else long_term_data for long_term_data, current_data in zip(self.mcu_f403a.long_term_min_list, self.mcu_f403a.osci_min_list)]
            
            
            channel_list.sort()
            y_max = -0.5 # the y-axis range of live-chart will be determined by the max among the self.mcu_f403a.osci_max_list
            
            
            if channel_list != []:
                
                
                for ch in channel_list:
                    
                    index = FIGURE_FORMAT['channel'].index(ch)
                    y_arr = y_arr_list[index]
                    line_color = FIGURE_FORMAT['osci_linecolor'][index]
                    
                    y_max = self.mcu_f403a.osci_max_list[index] if self.mcu_f403a.osci_max_list[index] > y_max else y_max
                    
                    
                    data = go.Scatter(
                        x=x,
                        y=y_arr,
                        name='Channel-%d'%ch,
                        mode= 'lines',
                        marker = dict(color = line_color),
                        line = dict(width=linewidth),
                        hovertemplate = 
                                        'V: %{y:.2f}'+
                                        '<br>%{text}</br>',
                        text = ['T: {:.1f}ms'.format(i/1020*rs_value) for i in range(1020)]
                        )
                
                    fig_data_list += [data]
                

            
            else:
                pass
                
            
            
            output_fig = {'data': fig_data_list,'layout' : FIGURE_FORMAT['Osci_layout']}
                
            
            
            ############################################Trigger control paragraph###################################
            if self.runing_state_ctrl:
                #trigger rising:
                if (tucl_chk1 != [] and self.mcu_f403a.osci_max_list[0] > tucl_1) or (tucl_chk2 != [] and self.mcu_f403a.osci_max_list[1] > tucl_2) or (tucl_chk3 != [] and self.mcu_f403a.osci_max_list[2] > tucl_3):
                    self.mcu_f403a.stop()
                    output_state = "Triggered!"
                    output_update_disable=True
                    self.runing_state_ctrl = False # State "Triggered" is seen as state "Stop"
                #trigger falling:  
                if (tlcl_chk1 != [] and self.mcu_f403a.osci_min_list[0] < tlcl_1) or (tlcl_chk2 != [] and self.mcu_f403a.osci_min_list[1] < tlcl_2) or (tlcl_chk3 != [] and self.mcu_f403a.osci_min_list[2] < tlcl_3):
                    self.mcu_f403a.stop()
                    output_state = "Triggered!"
                    output_update_disable=True
                    self.runing_state_ctrl = False # State "Triggered" is seen as state "Stop"
            ############################################Trigger control paragraph###################################
            
            
            ############################################showing the long-term monitoring data###################################
            # to display the stat val of a given channel ind, and it works only when "clear" btn is not triggered
            out_ind = int(tab_switch[-1])-1
            if len(x) > 0 and not (self.current_reset_click > self.last_reset_click):
                self.output_max = self.mcu_f403a.long_term_max_list[out_ind]
                self.output_min = self.mcu_f403a.long_term_min_list[out_ind]
                self.output_ave = self.mcu_f403a.osci_ave_list[out_ind]
                self.output_ucl_percent = self.mcu_f403a.osci_out_ucl_list[out_ind]
                self.output_lcl_percent = self.mcu_f403a.osci_out_lcl_list[out_ind]
            ############################################showing the long-term monitoring data###################################
                
            
            return output_fig, output_interval, output_state, output_update_disable, self.output_ucl_percent, self.output_lcl_percent, self.output_max, self.output_min, self.output_ave
        
        
        #re-layout the live oscilloscope
        @self.app.callback(
              Output('hidden-osci-div1', 'style'),
              [Input('live-graph', 'relayoutData')])
              
        def relayout_osci_graph(relayoutData):
            
            try:
                FIGURE_FORMAT['Osci_layout']['xaxis']['range'] = [relayoutData["xaxis.range[0]"],relayoutData["xaxis.range[1]"]]
                FIGURE_FORMAT['Osci_layout']['yaxis']['range'] = [relayoutData["yaxis.range[0]"],relayoutData["yaxis.range[1]"]]
            except:
                pass
            
            return {'display':'none'}
        

        
        # Runing State Control of DA system
        @self.app.callback(Output('loading-2-output', 'children'),
              [Input('start-2-button', 'n_clicks'),
              Input('reset-2-button', 'n_clicks'),
              Input('upload-2-button','n_clicks'),
              Input('da_limit_update_btn','n_clicks'),
              Input('live-2-graph', 'figure')],
              [State('start-2-button', 'children')], prevent_initial_call=True)
        def render_state_content(btn1, btn2, btn3, btn4, plot_trigger,  btn1_text): # this must be triggered at the begining by live-2-graph
            
            changed_id = [p['prop_id'] for p in dash.callback_context.triggered][0]
            
            if 'start-2-button' in changed_id and btn1 > 0:
                msg = 'Recording...' if btn1_text == "Record" else "Computing..."
            elif 'reset-2-button' in changed_id and btn2 > 0:
                msg = 'Clear!'
            elif 'upload-2-button' in changed_id and btn3 > 0:
                msg = 'Importing...'
            elif 'da_limit_update_btn' in changed_id and btn4 > 0:
                msg = 'Updating...'
            else:
                msg = "" #plot_trigger
                
            
            return msg
            
        
        # control of buttons: disable or enable when click and state changes
        @self.app.callback(
              [Output('start-2-button', 'disabled'),
              Output('reset-2-button', 'disabled'),
              Output('upload-2-button', 'disabled'),
              Output('da_limit_update_btn', 'disabled'),
              Output('openfolder-2-button', 'disabled'),
              Output('export-2-btn', 'disabled'),
              Output('dropdown-2-Rs', 'disabled'),
              Output('dropdown-DA-voltage', 'disabled'),
              Output('ud_ucl_input', 'disabled'),
              Output('ud_lcl_input', 'disabled'),
              Output('DA-linewidth', 'disabled')], 
              [Input('loading-2-output', 'children')], prevent_initial_call=True)
        def btns_disable_flow(msg): # this must be triggered at the begining by loading-2-output(msg)
            
            changed_id = [p['prop_id'] for p in dash.callback_context.triggered][0]
            time.sleep(0.1)
            
            if msg == "":
                # print("unlock all")
                return False, False, False, False, False, False, False, False, False, False, False
            elif msg == "Recording...":
                # print("lock all except Racord/Stop")
                return False, True, True, True, True, True, True, True, True, True, True
            else: # e.g. "Computing..." or "Importing..." or "Updating..." or "Clear!"
                # print("lock all")
                return True, True, True, True, True, True, True, True, True, True, True
        
        
        # timer for recording
        @self.app.callback(
            [Output("timer-2-output", "children"),
            Output("timer-interval", "disabled")],
            [Input('timer-interval', "n_intervals"),
            Input('loading-2-output', 'children')], 
            [State('timer-interval','interval')])
        def show_record_time(n_intervals, msg, interval):
            
            changed_id = [p['prop_id'] for p in dash.callback_context.triggered][0]
        
            # time.sleep(0.1)
            if msg == "Recording...":
                self.n_timer += 1
                return '{}s'.format(self.n_timer*interval/1000), False
            else:
                self.n_timer = 0
                return "", True
        
        
        
        # record button style and its children
        @self.app.callback([Output('start-2-button', 'children'),
                            Output('start-2-button', 'style')],
                           [Input('start-2-button', 'n_clicks'),
                           Input('reset-2-button', 'n_clicks'),
                           Input('upload-2-button','n_clicks'),
                           Input('da_limit_update_btn','n_clicks')],
                           [State('start-2-button', 'children')], prevent_initial_call=True)
        def change_start_btn_text(btn1, btn2, btn3, btn4, btn1_text):
            
            style_record = {'background-color': 'blue'}            
            style_stop = {'background-color': 'red'}
            
            changed_id = [p['prop_id'] for p in dash.callback_context.triggered][0]
            # print(changed_id)
            
            if 'start-2-button' in changed_id:
                
                if btn1_text == "Record":
                    return "Stop", style_stop
                else:
                    return "Record", style_record
            
            else:
                self.mcu_f403a.collect_long_data_enable = False
                return "Record", style_record
        
        ################################################# export table data ####################################################
        @self.app.callback(Output('hidden-DA-div5', 'style'),
                           [Input('export-2-btn', 'n_clicks')],
                           [State('data-2-table','data')], prevent_initial_call=True)
        def export_table_data(btn1, table_data):
            
            changed_id = [p['prop_id'] for p in dash.callback_context.triggered][0]
            
            if btn1 > 0:
                save_filename = save_by_filedialog_tk()
                if save_filename != None:
                    pd.DataFrame(table_data).to_csv(save_filename, index = False)
                else:
                    pass
            else:
                pass
            
            return {'display':'none'}
        ################################################# export table data ####################################################
        
        
        ################################################# record/stop flow ####################################################
        @self.app.callback(Output('hidden-DA-div1', 'style'),
                           [Input('start-2-button', 'n_clicks')],
                           [State('start-2-button', 'children'),
                           State('dropdown-2-Rs','value')], prevent_initial_call=True)
        def record_stop_flow(btn1, btn1_text, rs_value): # this must be triggered at the begining by start-2-button
            
            self.mcu_f403a.software_da_speed=float(rs_value)
            changed_id = [p['prop_id'] for p in dash.callback_context.triggered][0]
            
            if ('start-2-button' in changed_id):
                
                if btn1_text == "Record" and btn1 > 0:
                    
                    self.mcu_f403a.collect_long_data_enable = True
                    self.mcu_f403a.reset_data()

                    try: 
                        self.mcu_f403a.set_rs(system = 'DA')
                        self.data1, self.data2, self.data3 = self.mcu_f403a.collect_long_bauds(self.folder_path)
                    except:
                        pass
                        
                    
                
                else:
                    self.mcu_f403a.collect_long_data_enable = False
                    time.sleep(1)
                    
                    self.mcu_f403a.analyze_long_data(self.data1, self.data2, self.data3)
                
            
            return {'display':'none'}
        ################################################# record/stop flow ####################################################
        
        
        ################################################# upload flow ####################################################
        @self.app.callback(
              Output('hidden-DA-div2', 'style'),
              [Input('upload-2-button', 'n_clicks')],
              [State('dropdown-2-Rs','value')], prevent_initial_call=True)
        def upload_csv_flow(btn1, rs_value):
            
            changed_id = [p['prop_id'] for p in dash.callback_context.triggered][0]
            if btn1 > 0:
                
                self.mcu_f403a.software_da_speed=float(rs_value)
                
                
                self.output_string = ""
                self.upload_state=True
                self.mcu_f403a.reset_from_file_data()
                self.y_upload_arr_list = [np.array([])]*3 # used for statistic calculation
                
                filenames = upload_by_filedialog_tk()
                
             
                if filenames != None:                    
                    
                    filesize = 0
                    for filename in filenames:
                        filesize += getsize(filename)/1e6 #unit: MB
                    
                    
                    if len(filenames) <= 2: # check number of importing files
                        
                        if filesize <= 80: # check total size of importing files
                        
                            for filename in filenames:
                                
                                try: # exception occurs if content error: e.g. convert dll to csv and import it. 
                                    df = pd.read_csv(filename)
                                    if self.mcu_f403a.check_csv_format(df): # check columns name
                                        
                                        self.mcu_f403a.filenames += [filename]
                                        self.mcu_f403a.time_list_from_file += [df.iloc[:,0].values]
                                        self.mcu_f403a.data_list_c1_from_file += [df.iloc[:,1].values]
                                        self.mcu_f403a.data_list_c2_from_file += [df.iloc[:,2].values]
                                        self.mcu_f403a.data_list_c3_from_file += [df.iloc[:,3].values]
                                        
                                        self.y_upload_arr_list[0] = np.append(self.y_upload_arr_list[0], df.iloc[:,1].values)
                                        self.y_upload_arr_list[1] = np.append(self.y_upload_arr_list[1], df.iloc[:,2].values)
                                        self.y_upload_arr_list[2] = np.append(self.y_upload_arr_list[2], df.iloc[:,3].values)
                                        self.output_string += "{}, ".format(basename(filename))
                                    
                                    else:
                                        self.output_string = 'Failed! Incorrect data format in {}'.format(basename(filename))
                                        self.upload_state = False
                                        _output = f"date: {datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')}"+'  '+f'Error: format error in {basename(filename)}' + '\n'
                                        output_log(_output)
                                        break
                                
                                except Exception as e:
                                    self.output_string = 'Failed! Incorrect data format in {}'.format(basename(filename))
                                    self.upload_state = False
                                    _output = f"date: {datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')}"+'  '+f'Error: content error in {basename(filename)}' + '\n'
                                    output_log(_output)
                                    break
                        else:
                            self.output_string =  "Failed! Total size of files > 80 MB."
                            self.upload_state = False
                            pass
                        
                                    
                    else:
                        self.output_string =  "Failed! More than two files are imported."
                        self.upload_state = False
                        pass
                    
                    
                else:
                    self.output_string =  "No file imported!"
                    self.upload_state = False
                    pass
                
            
            return {'display':'none'}
        ################################################# upload flow ####################################################
        
        
        ################################################# reset/clear flow ####################################################
        @self.app.callback(
              Output('hidden-DA-div3', 'style'),
              [Input('reset-2-button', 'n_clicks')],
              [State('dropdown-2-Rs','value')], prevent_initial_call=True)
        def clear_data_flow(reset_clicks, rs_value):
            
            changed_id = [p['prop_id'] for p in dash.callback_context.triggered][0]
            self.mcu_f403a.software_da_speed=float(rs_value)
            self.mcu_f403a.reset_from_file_data()
            self.mcu_f403a.reset_data()
            self.output_string = ""
            self.fig_data_list_no_limits = []
            self.y_upload_arr_list = [np.array([])]*3 # used for statistic calculation
            
            
            time.sleep(0.1)
            try: 
                self.mcu_f403a.set_rs(system = 'DA')
            except:
                pass
                
            return {'display':'none'}
        
        
        ################################################# reset/clear flow ####################################################
        
        
        ################################################# open folder flow ####################################################        
        @self.app.callback(
              Output('folder-2-input', 'value'),
              [Input('openfolder-2-button', 'n_clicks')],
              [State('dropdown-2-Rs','value')], prevent_initial_call=True)
        def open_folder_flow(open_clicks, rs_value):
            
            changed_id = [p['prop_id'] for p in dash.callback_context.triggered][0]
            self.mcu_f403a.software_da_speed=float(rs_value)
            self.output_string = ""
            
            folder_path = open_folder_dialog_tk()
            
            if folder_path != None:
                self.folder_path = folder_path
            else:
                pass
            
            if self.folder_path != "./data/":
                return self.folder_path.replace("/","\\")
            else:
                return ""
        
        ################################################# open folder flow ####################################################
        
        ################################################# update control limit flow ####################################################
        @self.app.callback(
              Output('hidden-DA-div4', 'style'),
              [Input('da_limit_update_btn', 'n_clicks')],
              [State('dropdown-2-Rs','value')], prevent_initial_call=True)
        def update_limits_flow(btn1, rs_value):
        
            changed_id = [p['prop_id'] for p in dash.callback_context.triggered][0]
            
            self.mcu_f403a.software_da_speed=float(rs_value)
            if btn1 > 0:
                time.sleep(0.5)
                
            return {'display':'none'}
        
        
        
        ################################################# update control limit flow ####################################################
        
        
        ############################################ DA and Analysis system###############################################
        @self.app.callback(
              [Output('live-2-graph', 'figure'),
              Output('data-2-table', 'data'),
              Output('filename-2-input', 'value')],
              [Input('hidden-DA-div1', 'style'), # triggered by record/stop
              Input('hidden-DA-div2', 'style'), # triggered by upload
              Input('hidden-DA-div3', 'style'), # triggered by reset/clear
              Input('hidden-DA-div4', 'style')], # triggered by update flow
              [State('dropdown-DA-voltage','value'),
              State('ud_ucl_input','value'),
              State('ud_lcl_input','value'),
              State('DA-linewidth','value'),
              State('loading-2-output', 'children')], prevent_initial_call=True)

        def plot_da_graph(record_trigger, upload_trigger, reset_trigger, update_trigger, volt_value, UCL, LCL, linewidth, running_state):
            
            changed_id = [p['prop_id'] for p in dash.callback_context.triggered][0]
            chart_app.SPEC_PARAMS['DA']['lcl'] = np.around(LCL/1000, 3)
            chart_app.SPEC_PARAMS['DA']['ucl'] = np.around(UCL/1000, 3)
            chart_app.SPEC_PARAMS['DA']['v_ratio'] = volt_value
            
            LCL, UCL = chart_app.SPEC_PARAMS['DA']['lcl'], chart_app.SPEC_PARAMS['DA']['ucl']
            self.mcu_f403a.amplify_ratio_c1,  self.mcu_f403a.amplify_ratio_c2, self.mcu_f403a.amplify_ratio_c3 = [chart_app.SPEC_PARAMS['DA']['v_ratio']]*3

            
            fig_data_list = [go.Scatter()] # add an empty scatter to make modebar complete like osci-chart's effect (2021.08.30)
            output_table_data = []
            
            # activated by record/stop flow
            if 'hidden-DA-div1' in changed_id:
            
                if "Comput" in running_state:
                    
                    self.last_chart_data_from = 'record'
                    fig_data_list = []
                    
                    y_arr_list = [self.mcu_f403a.data_list_c1, self.mcu_f403a.data_list_c2, self.mcu_f403a.data_list_c3]
                    x = self.mcu_f403a.time_list
                     
                    # this line avoids out-of-index error (btw, used for UCL and LCL lines)
                    x_max = np.max(x) if check_arr_len(x) else 1.0
                    self.control_limit_x_max = x_max
                    
                    self.fig_data_list_no_limits = []
                    for c_num, y_arr in enumerate(y_arr_list, 1):
                        
                        data = go.Scatter(
                                x=x,
                                y=y_arr,
                                name='Channel-%d'%c_num,
                                mode= 'lines',
                                marker = dict(color = FIGURE_FORMAT['DA_linecolor'][c_num-1]),
                                line = dict(width=linewidth),
                                hovertemplate = 
                                    'V: %{y:.2f}'+
                                    '<br>T: %{x:.2f}s</br>'
                                )
                        
                        
                        fig_data_list += [data]
                        self.fig_data_list_no_limits += [data]
                    
                    
                    # total figure data
                    fig_data_list += self.make_control_limit_data(x_max,LCL,UCL,linewidth)
                    
                    # compute the statistic table
                    output_table_data = self.tablize_record_data(UCL, LCL)
                    
                    
                    try:
                        save_filename = save_by_filedialog_tk()
                        if save_filename != None:
                            _res = self.mcu_f403a.save_data(save_filename)
                            if _res:
                                # export_table(save_filename, output_table_data)
                                self.output_string = f"Save file to \"{save_filename}\"".replace("/","\\")
                            else:
                                self.output_string = f"file already saved: {self.mcu_f403a.last_save_filename}" 
                        
                        else:
                            self.output_string = "Cancel, fail to save file"
                        
                    except Exception as e:
                        # print(e)
                        self.output_string = "Error: cannot save file"

                        
                    
                    self.reset_da_baud_data() # reset useless byte data
                
                
                else:
                    output_table_data = TABLE_FORMAT['data']
            
            
            # activated by import flow
            elif 'hidden-DA-div2' in changed_id:
                
                if "Import" in running_state:
                    
                    if self.upload_state:
                        self.last_chart_data_from = 'import'
                        fig_data_list = []
                        # plot the graph
                        x_max = 0
                        self.fig_data_list_no_limits = []
                        for filename, time, data_c1, data_c2, data_c3 in zip(self.mcu_f403a.filenames, self.mcu_f403a.time_list_from_file, self.mcu_f403a.data_list_c1_from_file, self.mcu_f403a.data_list_c2_from_file, self.mcu_f403a.data_list_c3_from_file):
                            
                            filename = basename(filename)
                            root, extension = splitext(filename)
                            x_max = np.max(time) if x_max < np.max(time) else x_max
                            self.control_limit_x_max = x_max
                            
                            for c_num, y_arr in enumerate([data_c1, data_c2, data_c3],1):
                                
                                data = go.Scatter(
                                        x=time,
                                        y=y_arr,
                                        name=root+'-Channel-%d'%c_num,
                                        mode= 'lines',
                                        line = dict(width=linewidth),
                                        hovertemplate = 
                                            'V: %{y:.2f}'+
                                            '<br>T: %{x:.2f}s</br>'
                                        )
                                
                                
                                fig_data_list += [data]
                                self.fig_data_list_no_limits += [data]
                        
                        # total figure data
                        fig_data_list += self.make_control_limit_data(x_max,LCL,UCL,linewidth)
                        
                        # compute the statistic table
                        output_table_data = self.tablize_import_data(UCL, LCL)
                    
                    else:
                        output_table_data = TABLE_FORMAT['data']
                                                
                else:
                    output_table_data = TABLE_FORMAT['data']
                    self.output_string = "Interrputed, please try again."
            
            #activated by update btn
            elif 'hidden-DA-div4' in changed_id:
            
                fig_data_list = self.fig_data_list_no_limits + self.make_control_limit_data(self.control_limit_x_max,LCL,UCL,linewidth)
                
                if self.last_chart_data_from == 'record':
                    output_table_data = self.tablize_record_data(UCL, LCL)
                else:
                    output_table_data = self.tablize_import_data(UCL, LCL)
                    
            
            # activated by clear flow
            elif 'hidden-DA-div3' in changed_id:
                
                output_table_data = TABLE_FORMAT['data']
                
    
            else:
                output_table_data = TABLE_FORMAT['data']
                
            
            
            output_fig = {'data': fig_data_list,'layout' : FIGURE_FORMAT['DA_layout']}
            
            
            return output_fig, output_table_data, self.output_string
        
        ############################################ DA and Analysis system###############################################
        
        
    def reset_osci_stat_data(self):
        self.osci_stat_data = {
                                'n_points':0,
                                'reset_thr':36000, # 1hr = 3600 s = 3600000 ms = 36000 itrs
                                'order-0':{
                                            'channnel':1,
                                            'ave':np.array([]),
                                            'out_ucl':np.array([]),
                                            'out_lcl':np.array([])
                                        },
                                'order-1':{
                                            'channnel':2,
                                            'ave':np.array([]),
                                            'out_ucl':np.array([]),
                                            'out_lcl':np.array([])
                                        },
                                'order-2':{
                                            'channnel':3,
                                            'ave':np.array([]),
                                            'out_ucl':np.array([]),
                                            'out_lcl':np.array([])
                                        }
                            }   
        
    def reset_da_baud_data(self):
        self.data1, self.data2, self.data3 = [b'']*3
    
    
    def tablize_import_data(self, UCL, LCL):
        
        output_table_data = []
        for c_num, y_arr in enumerate(self.y_upload_arr_list, 1):
                  
            if check_arr_len(y_arr):
                 
                max_val, min_val, FD_val, ave_val, rms_val, std_val, cv_percentage, outPercentage = calculate_DA_features(y_arr, UCL, LCL)
                # print(max_val, min_val, FD_val, ave_val, rms_val, std_val, cv_percentage, outPercentage)
            else:
                max_val = 'N.A.'
                min_val = 'N.A.'
                FD_val = 'N.A.'
                ave_val = 'N.A.'
                rms_val = 'N.A.'
                std_val = 'N.A.'
                cv_percentage = 'N.A.'
                outPercentage = 'N.A.'
        
        
            output_table_data += [{'Item': 'Channel-%d'%c_num, 
                                    'Maximum Voltage(V)': max_val, 
                                    'Minimum Voltage(V)':min_val, 
                                    'Full Deviation(V)':FD_val, 
                                    'Average Voltage(V)':ave_val, 
                                    'RMS':rms_val,
                                    'STDEV(V)':std_val,
                                    'CV(%)':cv_percentage,
                                    'OutPercentage%':outPercentage
                                    }]
                                
                          
        return output_table_data
        
        
    
    def tablize_record_data(self, UCL, LCL):
    
        output_table_data = []
        y_arr_list = [self.mcu_f403a.data_list_c1, self.mcu_f403a.data_list_c2, self.mcu_f403a.data_list_c3]
        for c_num, y_arr in enumerate(y_arr_list, 1):
                        
            if check_arr_len(y_arr):
                
                max_val, min_val, FD_val, ave_val, rms_val, std_val, cv_percentage, outPercentage = calculate_DA_features(y_arr, UCL, LCL)
                
            else:
                max_val = 'N.A.'
                min_val = 'N.A.'
                FD_val = 'N.A.'
                ave_val = 'N.A.'
                rms_val = 'N.A.'
                std_val = 'N.A.'
                cv_percentage = 'N.A.'
                outPercentage = 'N.A.'


            output_table_data += [{'Item': 'Channel-%d'%c_num, 
                                    'Maximum Voltage(V)': max_val, 
                                    'Minimum Voltage(V)':min_val, 
                                    'Full Deviation(V)':FD_val, 
                                    'Average Voltage(V)':ave_val, 
                                    'RMS':rms_val,
                                    'STDEV(V)':std_val,
                                    'CV(%)':cv_percentage,
                                    'OutPercentage%':outPercentage
                                    }]
                                    
        return output_table_data
        
            
    
    def make_control_limit_data(self,x_max,LCL,UCL,linewidth):
        
        data_UCL = go.Scatter(
                        x = [0,x_max],
                        y = [UCL, UCL],
                        mode = "lines",
                        name = "UCL({:.3f}V)".format(UCL),
                        line = dict(dash = 'dot', color="honeydew", width=linewidth)
                        )
                
        data_LCL = go.Scatter(
                        x = [0,x_max],
                        y = [LCL, LCL],
                        mode = "lines",
                        name = "LCL({:.3f}V)".format(LCL),
                        line = dict(dash = 'dot', color="#2894FF", width=linewidth)
                        )
        
        return [data_LCL, data_UCL]


if __name__ == "__main__":
    waveformapp = WaveFormApp()
    print('run the server......')
    time.sleep(1)
    # waveformapp.app.run_server(port = waveformapp.web_port, host = waveformapp.web_host,threaded=True , debug = True)
    waveformapp.app.run_server(port = waveformapp.web_port, host = waveformapp.web_host,threaded=True)

