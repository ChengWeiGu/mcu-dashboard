import webbrowser


def open_browser():

    try:
        edge_path="C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
        webbrowser.register('edge', None, webbrowser.BackgroundBrowser(edge_path))
        webbrowser.get('edge').open('http://127.0.0.1:8888/')
        
    except:
        print("Edge Browser cannot be opened")
        


def open_web_by_learn_more_btn():
    
    try:
        asus_url = 'https://www.asus.com/tw/'
        webbrowser.open_new_tab(asus_url)
        # webbrowser.open_new(asus_url)
        
    except:
        print("Cannot access to the official website...")