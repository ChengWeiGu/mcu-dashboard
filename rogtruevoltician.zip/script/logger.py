import datetime
import os

def output_log(content):
    
    try:
        os.makedirs('./log/')
    except OSError:
        if not os.path.isdir('./log/'):
            raise

    _date = datetime.datetime.now().strftime('%Y%m%d')
    filename = f'./log/log_{_date}.txt'
    f = open(filename,'a+')
    f.write(content)
    f.write("-"*125+'\n')
    f.close()