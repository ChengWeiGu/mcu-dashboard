import numpy as np
import time
import datetime
import io
import pandas as pd
from os.path import dirname, basename, join, splitext
import os
from tkinter import Tk, filedialog


def open_folder_dialog_tk():
    root = Tk()
    root.iconbitmap("./script/assets/favicon.ico")
    root.withdraw()
    root.call('wm', 'attributes', '.', '-topmost', True)
    root.call('wm', 'attributes', '.', '-fullscreen', True)
    dir_ = filedialog.askdirectory(parent=root,title="Browse for Folder", initialdir='C:')
    root.destroy()
    
    if dir_ != "":
        return dir_
    else:
        return None
    

def upload_by_filedialog_tk():
    root = Tk()
    root.iconbitmap("./script/assets/favicon.ico")
    root.withdraw()
    root.call('wm', 'attributes', '.', '-topmost', True)
    root.call('wm', 'attributes', '.', '-fullscreen', True)
    filenames = filedialog.askopenfilenames(parent=root,title="Open", initialdir='C:', filetypes=(('csv files', 'csv'),))
    root.destroy()
    
    if filenames != "":
        return filenames
    else:
        return None
    
    return None


def save_by_filedialog_tk():
    root = Tk()
    root.iconbitmap("./script/assets/favicon.ico")
    root.withdraw()
    root.call('wm', 'attributes', '.', '-topmost', True)
    root.call('wm', 'attributes', '.', '-fullscreen', True)
    filename = filedialog.asksaveasfilename(parent=root,title="Save As", initialdir='C:',
                          defaultextension=".csv", filetypes=(("csv file", "*.csv"),("All Files", "*.*")))
    root.destroy()
    
    
    if filename != "":
        return filename
    else:
        return None