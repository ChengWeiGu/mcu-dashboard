import serial
import struct
import numpy as np
import pandas as pd
import serial.tools.list_ports as listCOMPort

import os
import time
import datetime
from script.ConfigReader import ConfigParameters
from script.views.ControlApp import SAMPLE_RATE
from script.views.ChartApp import SOFTWARE_SPEED
from script.logger import output_log

# ;G1_1s+: 40ms(25.5kHz), 50ms(20.4kHz), 100ms(10.2kHz)
# ;G2_0.3s: 10ms(102kHz), 20ms(51kHz), 30ms(34kHz)
# ;G3_0.1s: 2ms(510kHz), 5ms(204kHz), 8ms(127.5kHz)
# ;G4_0.03s: 0.68ms(1.5MHz), 0.75ms(1.36MHz), 1ms(1.02MHz), 1.5ms(682kHz)

columns = ['time(sec.)','Channel-1(V)','Channel-2(V)','Channel-3(V)']


class MCUF403A:
    
    def __init__(self):
        
        self.data_list_c1 = np.array([])
        self.data_list_c2 = np.array([])
        self.data_list_c3 = np.array([])
        self.time_list = np.array([])
        
        
        self.reset_features() # used for oscilloscope
        self.reset_from_file_data() # order: from_file1, from_file2,...
        
        
        self.n_time = 0
        self.check_sn_count = 0
        
        self.amplify_ratio_c1 = 3 # actually has 5 or 12 Volts 5/3
        self.amplify_ratio_c2 = 3 # actually has 5 or 12 Volts 5/3
        self.amplify_ratio_c3 = 3 # actually has 5 or 12 Volts 5/3
        
        
        self.parameters = ConfigParameters('./etc/Config.ini')
        
        self.last_save_filename = 'auto_save_data.csv'
        
        if self.parameters.comport == 'auto': #add on 2021/6/7
            self.comport = self.find_mcu()
        else:
            self.comport = self.parameters.comport
        
        self.collect_long_data_enable = False # use for breaking long-term collection
        
        self.trigger_s = 's'.encode('ascii') # start
        self.trigger_p = 'p'.encode('ascii') # end
        
        self.sample_rate_dict = SAMPLE_RATE
        self.software_speed = SOFTWARE_SPEED #default : 100ms for live chart
        self.software_da_speed = SOFTWARE_SPEED #default : 100ms for DA chart
        
        

    def find_mcu(self): #updated on 6/7
    
        comport = None
        com_info_list = list(listCOMPort.comports())
        target_vid_pid = 'VID:PID=2E3C:5740'
        
        print('search mcu...')
        
        search_date = datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')
        
        for com_info in com_info_list:
            com_name = com_info[0] # name, i.e. 'COM18'
            detail_str = com_info[2]
            connection_type = detail_str[:3] # 'USB' for wire connection, 'BTH' for BTHENUM
            
            index = detail_str.find('2E3C:5740')
            
            if index != -1:
                comport = com_name
                print(f'got mcu at {comport}...')
                # output = f'search_date: {search_date}' +'  '+ 'COM name: '+ com_info[0] + '  ' + 'Detail: ' + com_info[2] + '  ' + f'Is_MCU: {True}' + '\n'
                # output_log(output)
        
        if comport == None:
            print('Error: mcu cannot be found...')
            output = f'search_date: {search_date}' +'  '+'Error: mcu cannot be found...' + '\n'
            output_log(output)
        
            
        return comport
                
            
    def stop(self):
        try:
            self.device.write(self.trigger_p)
        except Exception as e:
            output = f"date: {datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')}"+'  '+f'Error: cannot trigger ASCII \'p\', {e}' + '\n'
            # output_log(output)
    
    
    def start(self):
        try:
            self.device.write(self.trigger_s)
        except Exception as e:
            output = f"date: {datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')}"+'  '+f'Error: cannot trigger ASCII \'s\', {e}' + '\n'
            # output_log(output)
    
    
    def __del__(self):
        try:
            self.disconnect_mcu()
            # print("mcu is turned off successfully")
        except:
            pass
            # print("mcu is already closed")
    
    
    def connect_mcu(self):
        try:
            self.device = serial.Serial(self.comport, self.parameters.baudrate , timeout = 1)
        except Exception as e:
            output = f"date: {datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')}"+'  '+f'Error: failed to connect mcu, {e}' + '\n'
            # output_log(output)
        
    
    def disconnect_mcu(self):
        try:
            self.stop()
            self.device.close()
        except Exception as e:
            output = f"date: {datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')}"+'  '+f'Error: failed to disconnect mcu, {e}' + '\n'
            # output_log(output)
            
    
    def set_rs(self, system = 'osci'):
        
        if system == 'osci':
            software_speed = self.software_speed
        elif system == 'DA':
            software_speed = self.software_da_speed
            
        
        self.trigger_sample_rate = self.sample_rate_dict[str(software_speed)]
        self.sample_rate = 1020/(software_speed/1000)
        
        self.connect_mcu()
        self.stop()
        
        try:
            self.device.write(serial.to_bytes(self.trigger_sample_rate))
        except Exception as e:
            output = f"date: {datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')}"+'  '+f'Error: Cannot send bps cmd to MCU, {e}' + '\n'
            # output_log(output)
            
        self.disconnect_mcu()
        
    
    
    def collect_long_bauds(self, auto_save_folder = './data/'):
        
        try:
            os.makedirs(auto_save_folder)
        except OSError:
            if not os.path.isdir(auto_save_folder):
                raise
        
        self.reset_data()
        num_bauds = 0
        data1 = b''
        data2 = b''
        data3 = b''
        self.connect_mcu()
        
        if self.device.isOpen():
        
            check_enable = True
            while check_enable:
                
                self.start()
                
                while True:
                
                    if self.collect_long_data_enable:
                    
                        all_data = self.device.read(6144)
                        L = len(all_data)
                        # print('total len = ',L)
                        if L == 6144:
                            channel_num1 = all_data[:2048][3]
                            channel_num2 = all_data[2048:4096][3]
                            channel_num3 = all_data[4096:6144][3]
                            baud_sn1 = all_data[:2048][2]
                            baud_sn2 = all_data[2048:4096][2]
                            baud_sn3 = all_data[4096:6144][2]
                            print("=> channel order {}, {}, {}".format(channel_num1, channel_num2, channel_num3))
                            print("=> baud sn {}, {}, {}".format(baud_sn1, baud_sn2, baud_sn3))
                            if (channel_num1 == 1 and channel_num2 == 2 and channel_num3 == 3) and (baud_sn1 == baud_sn2 == baud_sn3):
                                check_enable = False
                                num_bauds += 1
                                data1 += all_data[:2048][6:-2]
                                data2 += all_data[2048:4096][6:-2]
                                data3 += all_data[4096:6144][6:-2]
                                # print('append!')
                                
                                # if data too large, save it first
                                if num_bauds > 1000: # 1 baud = 74KB = 0.074 MB; 700 bauds = 51MB
                                    print("Saving data...")
                                    self.stop()
                                    datetime_now = datetime.datetime.now().strftime('%Y%m%d_%H%M%S_data')
                                    
                                    if auto_save_folder == './data/':
                                        save_filename = auto_save_folder + datetime_now + '.csv'
                                    else:
                                        save_filename = auto_save_folder + '/' + datetime_now + '.csv'
                                    
                                    self.last_save_filename = save_filename
                                    self.analyze_long_data(data1,data2,data3)
                                    _res = self.save_data(save_filename, compress = False)
                                    # initialization
                                    num_bauds = 0
                                    data1 = b''
                                    data2 = b''
                                    data3 = b''
                                    self.reset_data()
                                    self.start()

                            else:
                                print("check baud sn/order...")
                                check_enable = True
                                data1 = b''
                                data2 = b''
                                data3 = b''
                                break
                        else:
                            print('check baud length...')
                            check_enable = True
                            break
                    
                    else:
                        print('interrupted')
                        check_enable = False
                        break
                            
                
                self.stop()
                
        self.disconnect_mcu()
        
        
        return data1,data2,data3
    
    
    def collect_single_baud(self, filter_trigger_states = [0,0,0], filter_thresholds = [-0.5,-0.5,-0.5]): #the filtering function created on 2021/05/06
        
        data1 = b''
        data2 = b''
        data3 = b''
        
        
        if self.device.isOpen():
            
            self.start()
            all_data = self.device.read(6144)
            L = len(all_data)
            if L == 6144:
                channel_num1 = all_data[:2048][3]
                channel_num2 = all_data[2048:4096][3]
                channel_num3 = all_data[4096:6144][3]
                baud_sn1 = all_data[:2048][2]
                baud_sn2 = all_data[2048:4096][2]
                baud_sn3 = all_data[4096:6144][2]
                data1 = all_data[:2048][6:-2]
                data2 = all_data[2048:4096][6:-2]
                data3 = all_data[4096:6144][6:-2]
                print("=> channel order {}, {}, {}".format(channel_num1, channel_num2, channel_num3))
                print("=> baud sn {}, {}, {}".format(baud_sn1, baud_sn2, baud_sn3))
                if (channel_num1 == 1 and channel_num2 == 2 and channel_num3 == 3) and (baud_sn1 == baud_sn2 == baud_sn3):
                    
                    self.analyze_data(data1,data2,data3)
                    self.filter_max_points(filter_trigger_states, filter_thresholds)
                    self.check_sn_count = 0
  
                else:
                    print("baud sn/order error")
                    self.check_sn_count += 1
                    if self.check_sn_count > 5:
                        self.check_sn_count = 0
                        
                        self.disconnect_mcu()
                        self.set_rs(system = 'osci')
                        self.connect_mcu()
                        
                        # self.reset_data()
                        
            else:
                print('baud length error')
                self.stop()
    
    
    
    def analyze_long_data(self, byte_data1, byte_data2, byte_data3):
        
        n_baud = int(len(byte_data1)/2040)
        
        fmt = "<" + "h"*1020*n_baud
        
        aBaud_data1 = struct.unpack(fmt, byte_data1)
        aBaud_data2 = struct.unpack(fmt, byte_data2)
        aBaud_data3 = struct.unpack(fmt, byte_data3)
        
        self.data_list_c1 = np.array(aBaud_data1)*self.parameters.voltage_factor*self.amplify_ratio_c1/4095/3
        self.data_list_c2 = np.array(aBaud_data2)*self.parameters.voltage_factor*self.amplify_ratio_c2/4095/3
        self.data_list_c3 = np.array(aBaud_data3)*self.parameters.voltage_factor*self.amplify_ratio_c3/4095/3
        self.time_list = np.arange(0,1020*n_baud,1)/(self.sample_rate)
        
    
    
        
    def analyze_data(self,byte_data1,byte_data2,byte_data3):
        
        if self.n_time > 1000:
            self.n_time = 0
        
        fmt = "<" + "h"*1020
        self.n_time += 1
        
        aBaud_data1 = struct.unpack(fmt, byte_data1)
        aBaud_data2 = struct.unpack(fmt, byte_data2)
        aBaud_data3 = struct.unpack(fmt, byte_data3)
        
        self.data_list_c1 = self.linear_transform(aBaud_data1,1)
        self.data_list_c2 = self.linear_transform(aBaud_data2,2)
        self.data_list_c3 = self.linear_transform(aBaud_data3,3)
        self.time_list = np.arange(0,1020,1)
        
        
    def filter_max_points(self, filter_trigger_states, filter_thresholds):
        if filter_trigger_states[0] == 1: # channel-1
            self.data_list_c1 = self.data_list_c1[self.data_list_c1 < filter_thresholds[0]]
        if filter_trigger_states[1] == 1: # channel-2
            self.data_list_c2 = self.data_list_c2[self.data_list_c2 < filter_thresholds[1]]
        if filter_trigger_states[2] == 1: # channel-3
            self.data_list_c3 = self.data_list_c3[self.data_list_c3 < filter_thresholds[2]]
            

    
    def linear_transform(self, data, channel=1):
        
        if channel == 1:
            data = np.array(data)*self.parameters.voltage_factor*self.amplify_ratio_c1/4095/3
        elif channel == 2:
            data = np.array(data)*self.parameters.voltage_factor*self.amplify_ratio_c2/4095/3
        elif channel == 3:
            data = np.array(data)*self.parameters.voltage_factor*self.amplify_ratio_c3/4095/3
            
        return data
        
        
    def reset_data(self):
        self.n_time = 0
        self.data_list_c1 = np.array([])
        self.data_list_c2 = np.array([])
        self.data_list_c3 = np.array([])
        self.time_list = np.array([])
    
    def reset_from_file_data(self):
        self.filenames = []
        self.data_list_c1_from_file = []
        self.data_list_c2_from_file = []
        self.data_list_c3_from_file = []
        self.time_list_from_file = []
        
    
    def reset_features(self):
        # order: channel-1\channel-2\channel-3
        self.osci_max_list = [-0.5]*3
        self.osci_min_list = [15]*3
        
        self.long_term_max_list = [-0.5]*3 
        self.long_term_min_list = [15]*3
        
        self.osci_ave_list = [3.0]*3
        self.osci_out_ucl_list = [0]*3
        self.osci_out_lcl_list = [0]*3
        
    
    def save_data(self, filename, compress = False):
        
        time = self.time_list.reshape(-1,1)
        data1 = self.data_list_c1.reshape(-1,1)
        data2 = self.data_list_c2.reshape(-1,1)
        data3 = self.data_list_c3.reshape(-1,1)
        
        if len(time) > 0:
            
            merge_data = np.hstack([time,data1,data2,data3])
            
            if compress:
                compression_opts = dict(method='zip',archive_name=filename)
                pd.DataFrame(merge_data,columns = columns).to_csv(filename.replace('.csv','.zip'), index = False, compression=compression_opts)
            else:
                pd.DataFrame(merge_data,columns = columns).to_csv(filename, index = False)
            
            return True
            
        else:
            return False
    
    
    def check_csv_format(self, df):
        res = df.columns.tolist()==columns
        return res
    
    

if __name__ == "__main__":
     mcu_f403a = MCUF403A()
    
    